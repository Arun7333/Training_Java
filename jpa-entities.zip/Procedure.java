import jakarta.persistence.*;
import java.util.*;

@Entity
@Table(name = "procedures")
public class Procedure {

    @Id
    private UUID procedureId;

    private String patientId;
    private String procedureType;
    private Date plannedDate;

    @ManyToOne
    @JoinColumn(name = "created_by")
    private User createdBy;

    @Column(columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Date createdAt;

    // Constructors, Getters, Setters
}