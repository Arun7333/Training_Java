import java.io.Serializable;
import java.util.UUID;

public class TaskDependencyId implements Serializable {
    private UUID task;
    private UUID dependsOn;

    // Default constructor, equals, hashCode
}