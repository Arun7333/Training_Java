import jakarta.persistence.*;

@Entity
@Table(name = "procedure_team")
@IdClass(ProcedureTeamId.class)
public class ProcedureTeam {

    @Id
    @ManyToOne
    @JoinColumn(name = "procedure_id")
    private Procedure procedure;

    @Id
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "role_id")
    private Role role;

    // Constructors, Getters, Setters
}