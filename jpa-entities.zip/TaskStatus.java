public enum TaskStatus {
    TO_DO,
    IN_PROGRESS,
    DONE
}