public enum RoleScope {
    GLOBAL,
    PROCEDURE_SPECIFIC
}