import java.io.Serializable;
import java.util.UUID;

public class ProcedureTeamId implements Serializable {
    private UUID procedure;
    private UUID user;

    // Default constructor, equals, hashCode
}