import jakarta.persistence.*;

@Entity
@Table(name = "task_dependencies")
@IdClass(TaskDependencyId.class)
public class TaskDependency {

    @Id
    @ManyToOne
    @JoinColumn(name = "task_id")
    private Task task;

    @Id
    @ManyToOne
    @JoinColumn(name = "depends_on_task_id")
    private Task dependsOn;

    // Constructors, Getters, Setters
}